<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class UploadedFile extends Model{
    protected $table = "tl_uploaded_files";
}