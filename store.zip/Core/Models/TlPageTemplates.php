<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class TlPageTemplates extends Model
{
    protected $guarded = [];
}
