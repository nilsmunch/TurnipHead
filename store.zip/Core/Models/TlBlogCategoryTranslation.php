<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class TlBlogCategoryTranslation extends Model
{
    protected $guarded = [];
}
