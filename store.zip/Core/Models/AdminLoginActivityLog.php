<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class AdminLoginActivityLog extends Model
{
    protected $table = "admin_login_activity_log";
}