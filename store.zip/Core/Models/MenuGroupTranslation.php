<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;


class MenuGroupTranslation extends Model
{
    protected $table = "tl_menu_groups_translations";
}
