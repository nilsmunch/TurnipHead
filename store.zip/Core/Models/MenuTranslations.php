<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;


class MenuTranslations extends Model
{
    protected $table = "tl_menu_translations";
}