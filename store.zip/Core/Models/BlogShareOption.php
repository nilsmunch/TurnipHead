<?php

namespace Core\Models;
use Illuminate\Database\Eloquent\Model;

class BlogShareOption extends Model
{
    protected $table = "blog_share_options";
}
