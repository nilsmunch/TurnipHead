<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class TlBlogTranslation extends Model
{
    protected $guarded = [];
}
