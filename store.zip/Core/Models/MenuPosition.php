<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;


class MenuPosition extends Model
{
    protected $table = "tl_menu_positions";
}