<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\App;

class TlBlogTagTranslation extends Model
{
    protected $guarded = [];
}
