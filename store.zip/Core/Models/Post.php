<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $table = "tl_posts";
}
