<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class Countries extends Model
{
    protected $table = "tl_countries";
}
