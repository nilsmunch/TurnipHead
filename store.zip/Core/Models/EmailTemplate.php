<?php
namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class EmailTemplate extends Model{
    protected $table = "tl_email_template_properties";
}