<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class TlPageTranslation extends Model
{
    protected $guarded = [];
}
