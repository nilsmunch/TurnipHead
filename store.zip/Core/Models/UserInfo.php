<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class UserInfo extends Model
{
    protected $guarded = [];
    protected $table = "tl_user_informations";
}
