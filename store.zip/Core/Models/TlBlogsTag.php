<?php

namespace Core\Models;

use Illuminate\Database\Eloquent\Model;

class TlBlogsTag extends Model
{
    protected $guarded = [];   
}
