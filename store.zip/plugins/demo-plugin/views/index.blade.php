@extends('core::base.layouts.master')

@section('title')
    {{-- Page Title Here --}}
    {{ translate('Demo Pluin') }}
@endsection

@section('custom_css')
    {{-- Custom Style Here --}}
@endsection

@section('main_content')
    {{-- Main Content Here --}}
    <h1>Demo Plugin Content</h1>
@endsection

@section('custom_scripts')
    {{-- Custom Scripts Here --}}
@endsection
